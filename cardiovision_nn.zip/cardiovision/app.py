"""CardioVision AI - API + dashboard.   Run: uvicorn app:app --port 7860   then open http://localhost:7860"""
import json
import re
import time
import warnings
from functools import lru_cache
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import shap
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

warnings.filterwarnings("ignore")
A = Path(__file__).parent
B = joblib.load(A / "artifacts/model.joblib")
MET = json.loads((A / "artifacts/metrics.json").read_text())
F, SPEC, T, V = B["features"], B["spec"], ["CAD", "LAD", "LCX", "RCA"], ["LAD", "LCX", "RCA"]
NUM = {c for c in F if SPEC[c]["kind"] == "num"}
clean = lambda o: json.loads(json.dumps(o, default=lambda x: x.item() if hasattr(x, "item") else str(x)))
PRESETS = clean(B["presets"])


def frame(rows):
    X = pd.DataFrame(rows, columns=F)
    for c in F:
        X[c] = pd.to_numeric(X[c]) if c in NUM else X[c].astype(str)
    return X


def one(feats):
    return frame([[feats.get(c, SPEC[c]["default"]) for c in F]])


CAT = [c for c in F if c not in NUM]


def enc(X):  # SHAP's masker needs numbers: encode categoricals as option indices, decode inside the model wrapper
    X = X.copy()
    for c in CAT:
        X[c] = X[c].astype(str).map(lambda v, o=SPEC[c]["options"]: float(o.index(v)) if v in o else 0.0)
    return X.astype(float)


def wrap(m):
    def f(X):
        D = pd.DataFrame(np.asarray(X, float), columns=F)
        for c in CAT:
            D[c] = [SPEC[c]["options"][int(round(v))] for v in D[c]]
        return m.predict_proba(frame(D))[:, 1]
    return f


for _m in B["explainers"].values():   # joblib thread start-up dominates tiny SHAP batches
    if hasattr(_m.named_steps["m"], "n_jobs"):
        _m.set_params(m__n_jobs=1)
    if hasattr(_m.named_steps["m"], "n_estimators"):   # explainer twin: 100 trees is enough for stable attributions
        _m.set_params(m__n_estimators=min(100, _m.named_steps["m"].n_estimators))
BG = enc(frame(B["background"]))
EXPL = {t: shap.Explainer(wrap(B["explainers"][t]), shap.maskers.Independent(BG, max_samples=10), algorithm="permutation") for t in T}


class Req(BaseModel):
    features: dict = {}
    target: str = "CAD"


app = FastAPI(title="CardioVision AI")


@app.get("/api/meta")
def meta():
    keep = ("n_train", "n_test", "prevalence", "test", "conformal", "coherence", "leakage_audit", "calibration_curve_oof", "extra")
    return {"spec": SPEC, "order": F, "presets": PRESETS, "thresholds": B["thresholds"], "metrics": {k: MET[k] for k in keep},
            "chosen": {t: MET["model_selection"][t]["chosen"] for t in T}}


@app.post("/api/predict")
def predict(r: Req):
    X = one(r.features)
    p = {t: float(B["models"][t].predict_proba(X)[0, 1]) for t in T}
    vp = np.array([p[v] for v in V])
    p["CAD"] = float(np.clip(p["CAD"], vp.max(), min(1.0, vp.sum())))   # CAD <=> any vessel stenotic
    out = {}
    for t in T:
        k = "CAD_coh" if t == "CAD" else t
        s = [c for c, pc in ((0, 1 - p[t]), (1, p[t])) if 1 - pc <= B["conformal_q"][k]]
        status = "uncertain" if len(s) == 2 else "abstain" if not s else "elevated" if s == [1] else "not elevated"
        out[t] = {"p": p[t], "status": status, "above_screen_threshold": p[t] >= B["thresholds"][k]}
    out["warnings"] = [{"f": c, "value": float(r.features[c]), "min": SPEC[c]["min"], "max": SPEC[c]["max"]}
                       for c in F if c in NUM and c in r.features and not SPEC[c]["min"] <= float(r.features[c]) <= SPEC[c]["max"]][:5]
    return out


@lru_cache(maxsize=256)
def _explain(key, t):
    X = one(dict(json.loads(key)))
    v = EXPL[t](enc(X), max_evals=2 * len(F) + 1).values[0]
    rows = [{"f": c, "value": float(X[c].iloc[0]) if c in NUM else str(X[c].iloc[0]), "pp": float(s) * 100, "group": SPEC[c]["group"]}
            for c, s in zip(F, v)]
    groups = {}
    for r in rows:
        groups[r["group"]] = groups.get(r["group"], 0) + r["pp"]
    return {"top": sorted(rows, key=lambda r: -abs(r["pp"]))[:10], "groups": groups}


@app.post("/api/explain")
def explain(r: Req):
    return _explain(json.dumps(sorted(r.features.items())), r.target)



_explain(json.dumps(sorted(PRESETS["medium"].items())), "LAD")   # warm-up: first SHAP call compiles numba code
app.mount("/", StaticFiles(directory=A / "static", html=True), name="static")
