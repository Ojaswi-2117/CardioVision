"""CardioVision AI - training pipeline (Track A).
Run:  python train.py --data "Z-Alizadeh sani dataset.xlsx"     (or omit --data to use ucimlrepo id=411)
Produces artifacts/model.joblib + artifacts/metrics.json (everything the API / dashboard needs).
"""
import argparse, json, warnings
from pathlib import Path
import joblib, numpy as np, pandas as pd
from sklearn.base import clone
from sklearn.calibration import CalibratedClassifierCV, calibration_curve
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, brier_score_loss, f1_score,
                             precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import (RepeatedStratifiedKFold, StratifiedKFold,
                                     cross_val_predict, cross_validate, train_test_split)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

warnings.filterwarnings("ignore")
SEED, ALPHA = 42, 0.10                      # ALPHA: conformal miscoverage (90% coverage target)
OUT = Path("artifacts"); OUT.mkdir(exist_ok=True)
VESSELS = ["LAD", "LCX", "RCA"]
POS = {"1", "cad", "stenotic", "yes", "y", "true", "abnormal", "present"}
ECG = {"st elevation", "st depression", "tinversion", "t inversion", "lvh", "q wave", "poor r progression", "bbb"}
LABECHO = {"fbs", "cr", "tg", "ldl", "hdl", "bun", "esr", "hb", "k", "na", "wbc", "lymph", "neut", "plt", "ef-tte", "region rwma", "vhd"}
DEMO = {"age", "weight", "length", "sex", "bmi", "dm", "htn", "current smoker", "ex-smoker", "fh", "obesity", "crf", "cva", "airway disease", "thyroid disease", "chf", "dlp"}
MODIFIABLE = {"bp", "fbs", "ldl", "hdl", "tg", "weight", "bmi", "current smoker", "pr"}


def group(c):
    c = c.lower()
    return "ECG" if c in ECG else "Lab & Echo" if c in LABECHO else "Demographic & history" if c in DEMO else "Symptoms & exam"


def to_bin(s):
    if pd.api.types.is_numeric_dtype(s):
        return (s > 0).astype(int).to_numpy()
    return s.astype(str).str.strip().str.lower().isin(POS).astype(int).to_numpy()


def load(path):
    if path:
        df = pd.read_excel(path) if path.lower().endswith(("xlsx", "xls")) else pd.read_csv(path)
    else:
        from ucimlrepo import fetch_ucirepo
        d = fetch_ucirepo(id=411)
        df = pd.concat([d.data.features, d.data.targets], axis=1)
    df.columns = [str(c).strip() for c in df.columns]
    return df


def prep(X):
    cat = X.select_dtypes(exclude="number").columns.tolist()
    num = [c for c in X.columns if c not in cat]
    return ColumnTransformer([
        ("n", Pipeline([("i", SimpleImputer(strategy="median")), ("s", StandardScaler())]), num),
        ("c", Pipeline([("i", SimpleImputer(strategy="most_frequent")),
                        ("o", OneHotEncoder(handle_unknown="ignore", sparse_output=False))]), cat)],
        sparse_threshold=0)


def candidates(X):
    mk = lambda est: Pipeline([("p", prep(X)), ("m", est)])
    return {"logreg": mk(LogisticRegression(C=0.5, max_iter=3000, class_weight="balanced")),
            "rf": mk(RandomForestClassifier(400, min_samples_leaf=2, class_weight="balanced_subsample", random_state=SEED, n_jobs=-1)),
            "hgb": mk(HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, max_iter=150, random_state=SEED))}


def metrics(y, p, t=0.5):
    h = (p >= t).astype(int)
    return {"accuracy": accuracy_score(y, h), "precision": precision_score(y, h, zero_division=0),
            "recall": recall_score(y, h, zero_division=0), "f1": f1_score(y, h, zero_division=0),
            "roc_auc": roc_auc_score(y, p), "brier": brier_score_loss(y, p)}


def boot_ci(y, p, n=1000):
    rng, vals = np.random.default_rng(SEED), {"roc_auc": [], "f1": []}
    for _ in range(n):
        b = rng.integers(0, len(y), len(y))
        if len(set(y[b])) < 2:
            continue
        m = metrics(y[b], p[b])
        for k in vals:
            vals[k].append(m[k])
    return {k: [float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))] for k, v in vals.items()}


def screen_threshold(y, p, min_recall=0.85):
    ok = [t for t in np.linspace(0.05, 0.95, 91) if recall_score(y, (p >= t).astype(int)) >= min_recall]
    return float(max(ok)) if ok else 0.5


def conformal_q(y, p, alpha=ALPHA):
    s = np.where(y == 1, 1 - p, p)           # nonconformity = 1 - prob of the true class
    k = min(np.ceil((len(s) + 1) * (1 - alpha)) / len(s), 1.0)
    return float(np.quantile(s, k, method="higher"))


def conf_report(y, p, q):
    in_set = np.where(y == 1, 1 - p <= q, p <= q)
    both = (1 - p <= q) & (p <= q)
    none = (1 - p > q) & (p > q)
    return {"q": q, "coverage": float(in_set.mean()), "uncertain_rate": float(both.mean()), "abstain_rate": float(none.mean())}


def coherent(p_cad, P):
    """CAD <=> at least one vessel stenotic, so max(P_vessel) <= P(CAD) <= min(1, sum P_vessel)."""
    return np.minimum(np.maximum(p_cad, P.max(1)), np.minimum(1.0, P.sum(1)))


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--data"); a = ap.parse_args()
    df = load(a.data)
    cad_col = next((c for c in df.columns if c.lower() in ("cath", "cad")), None)
    ves = [next(c for c in df.columns if c.lower() == v.lower()) for v in VESSELS]
    assert cad_col, "No Cath/CAD column found - check df.columns"
    Y = pd.DataFrame({"CAD": to_bin(df[cad_col]), **{c.upper(): to_bin(df[c]) for c in ves}})
    print("positives:\n", Y.mean().round(3).to_string())
    agree = float((Y.CAD == Y[VESSELS].max(axis=1)).mean())
    print(f"CAD == any-vessel-stenotic in {agree:.1%} of rows (should be ~100%; if not, check label mapping)")
    leak = ves + [c for c in df.columns if c.lower() in ("cath", "cad")]
    X = df.drop(columns=leak)
    tr, te = train_test_split(np.arange(len(X)), test_size=0.2, stratify=Y.CAD, random_state=SEED)
    Xtr, Xte, Ytr, Yte = X.iloc[tr], X.iloc[te], Y.iloc[tr], Y.iloc[te]
    cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=3, random_state=SEED)
    skf = StratifiedKFold(5, shuffle=True, random_state=SEED)

    M, EXP, OOF, PTE, SEL, THR = {}, {}, {}, {}, {}, {}
    for t in VESSELS + ["CAD"]:
        y = Ytr[t].to_numpy()
        res = {}
        for n, m in candidates(Xtr).items():
            s = cross_validate(m, Xtr, y, cv=cv, scoring=["roc_auc", "f1"])
            res[n] = {"cv_auc": float(s["test_roc_auc"].mean()), "cv_auc_std": float(s["test_roc_auc"].std()), "cv_f1": float(s["test_f1"].mean())}
        best = max(res, key=lambda k: res[k]["cv_auc"])
        mk = lambda: CalibratedClassifierCV(candidates(Xtr)[best], method="sigmoid", cv=5)
        M[t] = mk().fit(Xtr, y)
        EXP[t] = clone(candidates(Xtr)[best]).fit(Xtr, y)       # uncalibrated twin, used for SHAP
        OOF[t] = cross_val_predict(mk(), Xtr, y, cv=skf, method="predict_proba")[:, 1]
        PTE[t] = M[t].predict_proba(Xte)[:, 1]
        THR[t] = screen_threshold(y, OOF[t])
        SEL[t] = {"chosen": best, "candidates": res}
        print(f"{t}: chosen={best}  cv_auc={res[best]['cv_auc']:.3f}")

    P_oof = np.column_stack([OOF[v] for v in VESSELS]); P_te = np.column_stack([PTE[v] for v in VESSELS])
    coh_oof, coh_te = coherent(OOF["CAD"], P_oof), coherent(PTE["CAD"], P_te)
    OOF["CAD_coh"], PTE["CAD_coh"], THR["CAD_coh"] = coh_oof, coh_te, screen_threshold(Ytr.CAD.to_numpy(), coh_oof)
    Yte_ = {**{t: Yte[t].to_numpy() for t in VESSELS + ["CAD"]}, "CAD_coh": Yte.CAD.to_numpy()}
    Ytr_ = {**{t: Ytr[t].to_numpy() for t in VESSELS + ["CAD"]}, "CAD_coh": Ytr.CAD.to_numpy()}

    TEST, CONF = {}, {}
    for t in OOF:
        q = conformal_q(Ytr_[t], OOF[t]); CONF[t] = conf_report(Yte_[t], PTE[t], q)
        TEST[t] = {"at_0.5": metrics(Yte_[t], PTE[t]), "at_screen": metrics(Yte_[t], PTE[t], THR[t]),
                   "screen_threshold": THR[t], "ci95": boot_ci(Yte_[t], PTE[t])}

    # leakage audit: what happens if vessel labels are (wrongly) left in as CAD features
    leaky = df.drop(columns=[c for c in df.columns if c.lower() in ("cath", "cad")]).iloc[tr]
    lk = cross_validate(candidates(leaky)["logreg"], leaky, Ytr.CAD.to_numpy(), cv=skf, scoring="roc_auc")["test_score"].mean()
    clean = cross_validate(candidates(Xtr)["logreg"], Xtr, Ytr.CAD.to_numpy(), cv=skf, scoring="roc_auc")["test_score"].mean()
    frac, mean_p = calibration_curve(Ytr.CAD.to_numpy(), coh_oof, n_bins=6, strategy="quantile")

    spec = {}
    for c in X.columns:
        if pd.api.types.is_numeric_dtype(X[c]):
            spec[c] = {"kind": "num", "min": float(X[c].min()), "max": float(X[c].max()), "default": float(X[c].median())}
        else:
            spec[c] = {"kind": "cat", "options": sorted(X[c].dropna().astype(str).unique().tolist()), "default": str(X[c].mode()[0])}
        spec[c].update(group=group(c), modifiable=c.lower() in MODIFIABLE)
    order = np.argsort(coh_te); pick = {k: int(order[int(len(order) * f)]) for k, f in (("low", 0.1), ("medium", 0.5), ("high", 0.9))}
    presets = {k: Xte.iloc[i].to_dict() for k, i in pick.items()}

    joblib.dump({"models": M, "explainers": EXP, "features": list(X.columns), "spec": spec, "background": Xtr.sample(min(60, len(Xtr)), random_state=SEED),
                 "conformal_q": {t: CONF[t]["q"] for t in CONF}, "thresholds": THR, "presets": presets}, OUT / "model.joblib")
    report = {"n_train": len(tr), "n_test": len(te), "prevalence": Y.mean().to_dict(), "label_check_cad_equals_any_vessel": agree,
              "model_selection": SEL, "test": TEST, "conformal": CONF,
              "coherence": {"direct_cad_below_max_vessel_rate": float((PTE["CAD"] < P_te.max(1) - 1e-9).mean()),
                            "cad_auc_direct": float(roc_auc_score(Yte.CAD, PTE["CAD"])), "cad_auc_coherent": float(roc_auc_score(Yte.CAD, coh_te)),
                            "cad_brier_direct": float(brier_score_loss(Yte.CAD, PTE["CAD"])), "cad_brier_coherent": float(brier_score_loss(Yte.CAD, coh_te))},
              "leakage_audit": {"cad_auc_with_vessel_columns_as_features": float(lk), "cad_auc_clean": float(clean)},
              "calibration_curve_oof": {"mean_predicted": mean_p.tolist(), "fraction_positive": frac.tolist()}}
    (OUT / "metrics.json").write_text(json.dumps(report, indent=2, default=float))
    print("\nTEST (n=%d)  AUC [95%% CI]" % len(te))
    for t in TEST:
        print(f"  {t:8s} AUC={TEST[t]['at_0.5']['roc_auc']:.3f} {np.round(TEST[t]['ci95']['roc_auc'], 3)}  recall@screen={TEST[t]['at_screen']['recall']:.2f}  conformal coverage={CONF[t]['coverage']:.2f}")
    print("Leakage audit AUC:", round(lk, 3), "(leaky) vs", round(clean, 3), "(clean)")


if __name__ == "__main__":
    main()
