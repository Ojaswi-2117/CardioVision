"""Bakes approximate supply-territory weights onto the heart shell: for every shell vertex, how close it is to the LAD, LCX and RCA.
Purely geometric (distance to the artery mesh) - NOT derived from clinical features and NOT a lesion map."""
import json, numpy as np, trimesh
from scipy.spatial import cKDTree
g = trimesh.load("static/coronary_tree.glb").geometry
H = list(trimesh.load("static/heart_ghost.glb").geometry.values())[0].vertices
d = np.column_stack([cKDTree(g[n].vertices).query(H)[0] for n in ("LAD", "LCX", "RCA")])
w = np.exp(-(d / 0.30) ** 2)                                  # soft, overlapping territories (tree units)
w = w / np.maximum(w.sum(1, keepdims=True), 1e-6) * np.exp(-(d.min(1, keepdims=True) / 0.55) ** 2)   # normalise, fade far from any artery
json.dump({"w": np.round(w, 3).ravel().tolist()}, open("static/territory.json", "w"))
print("vertices", len(H), "| mean territory share LAD/LCX/RCA:", w.mean(0).round(3))
