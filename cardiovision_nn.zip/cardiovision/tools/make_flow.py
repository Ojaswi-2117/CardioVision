"""Bakes a per-vertex 'distance along the artery from the aortic root' so the viewer can animate blood flow that follows the real mesh."""
import json, numpy as np, trimesh
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra
from scipy.spatial import cKDTree
GLB, COR = "static/coronary_tree.glb", ["LAD", "LCX", "RCA", "LeftMainStem", "PosteriorInterventricular"]
g = trimesh.load(GLB).geometry
V = np.vstack([g[n].vertices for n in COR]); off = np.cumsum([0] + [len(g[n].vertices) for n in COR])
r, c = [], []
for i, n in enumerate(COR):
    f = g[n].faces + off[i]; r += [f[:, 0], f[:, 1], f[:, 2]]; c += [f[:, 1], f[:, 2], f[:, 0]]
r, c = np.concatenate(r), np.concatenate(c)
P = np.array(list(cKDTree(V).query_pairs(0.035)))          # bridge separate OBJ segments that touch (~2 mm)
if len(P): r, c = np.concatenate([r, P[:, 0]]), np.concatenate([c, P[:, 1]])
w = np.linalg.norm(V[r] - V[c], axis=1) + 1e-6
G = coo_matrix((w, (r, c)), shape=(len(V),) * 2).tocsr()
A = g["Aorta"].vertices.mean(0)
near = lambda n: off[COR.index(n)] + np.argmin(np.linalg.norm(g[n].vertices - A, axis=1))
d = dijkstra(G, directed=False, indices=[near("LeftMainStem"), near("RCA")], min_only=True)
bad = ~np.isfinite(d); d[bad] = np.linalg.norm(V[bad] - A, axis=1) * 1.3
print("graph-connected vertices: %.1f%%  max flow distance %.2f" % (100 * (1 - bad.mean()), d.max()))
json.dump({n: np.round(d[off[i]:off[i + 1]], 3).tolist() for i, n in enumerate(COR)}, open("static/flow.json", "w"))
