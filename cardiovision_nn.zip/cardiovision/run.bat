@echo off
setlocal
cd /d "%~dp0"
title CardioVision AI
set "PY="
for %%V in (3.12 3.13 3.14 3.11) do if not defined PY (py -%%V --version >nul 2>nul && set "PY=py -%%V")
if not defined PY for %%P in ("C:\Python314\python.exe" "C:\Python313\python.exe" "C:\Python312\python.exe" "%LocalAppData%\Programs\Python\Python314\python.exe" "%LocalAppData%\Programs\Python\Python313\python.exe" "%LocalAppData%\Programs\Python\Python312\python.exe") do if not defined PY if exist %%P set PY="%%~P"
if not defined PY (
  echo Python 3.11+ not found. Installing Python 3.12 with winget ^(one time^)...
  winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements --silent
  py -3.12 --version >nul 2>nul && set "PY=py -3.12"
)
if not defined PY (
  echo.
  echo Could not set up Python automatically.
  echo Install Python 3.12 from https://www.python.org/downloads/ ^(tick "Add python.exe to PATH"^) and run run.bat again.
  pause
  exit /b 1
)
echo Using %PY%
if not exist venv\Scripts\python.exe %PY% -m venv venv
venv\Scripts\python.exe -m pip install --quiet --upgrade pip
venv\Scripts\python.exe -m pip install --quiet -r requirements.txt
if errorlevel 1 (
  echo Package install failed - check your internet connection and run run.bat again.
  pause
  exit /b 1
)
echo.
echo CardioVision AI is starting. Your browser opens in about 30 seconds: http://localhost:7860
echo Keep this window open while you use the app. Close it to stop.
start "" cmd /c "timeout /t 30 /nobreak >nul & start http://localhost:7860"
venv\Scripts\python.exe -m uvicorn app:app --port 7860
pause
