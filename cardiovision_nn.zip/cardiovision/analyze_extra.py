"""Extra evidence for the dashboard (run after train.py):  python analyze_extra.py --data "<file>.xlsx"
 1) modality ablation: cross-validated ROC-AUC as clinical data modalities are added (demographic -> +symptoms/exam -> +ECG -> +lab/echo)
 2) decision-curve analysis (net benefit) of the coherent CAD risk on the held-out test set."""
import argparse, json
import joblib, numpy as np
from sklearn.model_selection import RepeatedStratifiedKFold, cross_val_score, train_test_split
from train import OUT, SEED, VESSELS, candidates, coherent, group, load, to_bin

ap = argparse.ArgumentParser(); ap.add_argument("--data"); a = ap.parse_args()
df = load(a.data)
cad_col = next(c for c in df.columns if c.lower() in ("cath", "cad"))
ves = [next(c for c in df.columns if c.lower() == v.lower()) for v in VESSELS]
Y = {"CAD": to_bin(df[cad_col]), **{c.upper(): to_bin(df[c]) for c in ves}}
X = df.drop(columns=ves + [c for c in df.columns if c.lower() in ("cath", "cad")])
tr, te = train_test_split(np.arange(len(X)), test_size=0.2, stratify=Y["CAD"], random_state=SEED)   # identical split to train.py
Xtr, Xte = X.iloc[tr], X.iloc[te]
M = json.loads((OUT / "metrics.json").read_text())
cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=2, random_state=SEED)
ORDER = ["Demographic & history", "Symptoms & exam", "ECG", "Lab & Echo"]
abl = {}
for t in ["CAD"] + VESSELS:
    best, rows = M["model_selection"][t]["chosen"], []
    for k in range(1, 5):
        cols = [c for c in X.columns if group(c) in ORDER[:k]]
        m = candidates(Xtr[cols])[best]
        if "n_estimators" in m.named_steps["m"].get_params():
            m.set_params(m__n_estimators=150)
        s = cross_val_score(m, Xtr[cols], Y[t][tr], cv=cv, scoring="roc_auc")
        rows.append({"added": ORDER[k - 1], "n_features": len(cols), "auc": float(s.mean()), "std": float(s.std())})
    abl[t] = rows
    print(t, [round(r["auc"], 3) for r in rows])
B = joblib.load(OUT / "model.joblib")
P = {t: B["models"][t].predict_proba(Xte)[:, 1] for t in ["CAD"] + VESSELS}
pc, y = coherent(P["CAD"], np.column_stack([P[v] for v in VESSELS])), Y["CAD"][te]
ths = np.linspace(0.05, 0.85, 17); n, prev = len(y), y.mean()
nb = lambda t: float((((pc >= t) & (y == 1)).sum() - ((pc >= t) & (y == 0)).sum() * t / (1 - t)) / n)
M["extra"] = {"modality_ablation": abl, "decision_curve": {"thresholds": ths.tolist(), "model": [nb(t) for t in ths],
              "treat_all": [float(prev - (1 - prev) * t / (1 - t)) for t in ths], "n": int(n), "prevalence": float(prev)}}
(OUT / "metrics.json").write_text(json.dumps(M, indent=2, default=float))
print("decision curve (test n=%d): model vs treat-all at t=0.3: %.3f vs %.3f" % (n, nb(0.3), prev - (1 - prev) * 0.3 / 0.7))
