#!/usr/bin/env bash
cd "$(dirname "$0")"
[ -d venv ] || python3 -m venv venv
source venv/bin/activate
pip install -q -r requirements.txt
(sleep 30; (open http://localhost:7860 || xdg-open http://localhost:7860) >/dev/null 2>&1) &
python -m uvicorn app:app --port 7860
